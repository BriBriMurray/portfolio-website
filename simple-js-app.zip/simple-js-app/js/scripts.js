alert('Hello World');
let favoriteFood = 'Avocado';
document.write(favoriteFood);